<header>
    <div class="container-fluid">
        <div class="menubar">
            <a href="<?php echo e(route('dashboard')); ?>">
                <h2 class="logo-text">Watcher</h2>
            </a>
            <a href="#" class="humburger">
                <span class="humburger-lg"></span>
                <span class="humburger-sm"></span>
                <span class="humburger-lg"></span>
                <span class="humburger-sm"></span>
            </a>
            <ul class="menu">
                <li>
                    <a href="#">Campaigns <i class="fa fa-caret-down" aria-hidden="true"></i></a>
                    <ul class="submenu">
                        <li><a href="new-campaign.html">Create New Campaign</a></li>
                        <li><a href="#">My Campaigns</a></li>
                        <li><a href="#">My Youtube Channels</a></li>
                    </ul>
                </li>
                <li><a href="<?php echo e(route('stats.index')); ?>">Stats</a></li>
                <li><a href="<?php echo e(route('credit.index')); ?>">Credits</a></li>
                <li><a href="<?php echo e(route('refers.index')); ?>">Refer</a></li>
                <li><a href="<?php echo e(route('download.index')); ?>">Download Extension</a></li>
                <li>
                    <a href="<?php echo e(route('users.index')); ?>">Users</a>
                </li>

                <li>
                    <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                               document.getElementById('logout-form').submit();">
                        <i class="bx bx-log-out"></i> Logout
                    </a>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                        <?php echo csrf_field(); ?>
                    </form>
                </li>


            </ul>
        </div>
    </div>
</header><?php /**PATH C:\xampp\htdocs\watcher\resources\views/layouts/admin-header.blade.php ENDPATH**/ ?>