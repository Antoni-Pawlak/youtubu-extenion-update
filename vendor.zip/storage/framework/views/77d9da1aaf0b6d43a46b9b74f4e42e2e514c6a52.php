<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <section>
        <div class="container-fluid">
            <!-- breadcrumb -->
            <div class="breadcrumb-header justify-content-between">
                <div class="my-auto">
                    <div class="d-flex">
                        <h4 class="content-title mb-0 my-auto">All Keywords</h4><span class="text-muted mt-1 tx-13 ms-2 mb-0">/ list</span>
                    </div>
                </div>
                <a class="btn btn-main-primary ml_auto" href="<?php echo e(route('backlink.create')); ?>">Add Keywords</a>
            </div>
            <!-- breadcrumb -->

            <div class="row row-sm">
                <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 grid-margin">
                    <div class="card">
                        <div class="card-header pb-0">
                            <p class="tx-12 tx-gray-500 mb-2">Listing of All Keywords...</p>
                        </div>
                        <div class="card-body">

                            <!-- Listing all data in user tables -->
                            <div class="table-responsive border-top userlist-table">
                                <table class="table card-table table-striped table-vcenter text-nowrap mb-0" id="backlink-table">
                                    <thead>
                                        <tr>
                                            <th class="wd-lg-20p"><span>Keywords</span></th>
                                            <th class="wd-lg-20p"><span>Video link</span></th>
                                            <th class="wd-lg-20p"><span>Start Time</span></th>
                                            <th class="wd-lg-20p"><span>End Time</span></th>
                                            <th class="wd-lg-20p"><span>Created</span></th>
                                            <th class="wd-lg-20p">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>

                                    </tbody>
                                </table>
                            </div>

                        </div>
                    </div>
                </div>
                <!-- COL END -->
            </div>

        </div>
    </section>

    <!-- model end -->


 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH E:\xampp\htdocs\watcher\resources\views/backlink/index.blade.php ENDPATH**/ ?>