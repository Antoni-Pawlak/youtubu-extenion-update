<footer>
    <div class="container">
        <p>Copyright 2023 .All Rights Reserved.</p>
    </div>
</footer>